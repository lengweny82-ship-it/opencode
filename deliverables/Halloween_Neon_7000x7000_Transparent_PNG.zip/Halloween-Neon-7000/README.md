# Halloween Neon - 7000 x 7000 Transparent PNG

## الملفات
- المجموعة تحتوي على 10 صور منفصلة، كل صورة 7000×7000 بكسل فعلًا.
- الصيغة PNG ونظام الألوان RGBA، مع شفافية حقيقية خارج التصميم.
- تم الحفاظ على الخلفية البنفسجي داخل الدائرة وعلى الشخصيات البيضاء والإطار الكريمي؛ دول جزء من الرسمة، مش الخلفية البيضاء المطلوب حذفها.
- ملفات manifest.csv وmanifest.json توضح المقاس والصيغة والشفافية وبصمة كل ملف.

## طريقة التكبير
- الصور الأصلية كانت 1024×1024. تم تكبيرها بخوارزمية Lanczos مع معالجة صحيحة لحواف الشفافية.
- ده تكبير حسابي، مش إعادة توليد أو AI super-resolution، ومش بيخلق تفاصيل أصلية جديدة.
- تمت إضافة بيانات 300 DPI، لكن تغيير DPI وحده لا يضيف تفاصيل.
- تم تحسين خطوات RGB لتقليل حجم التحميل، بفرق لوني طفيف موضح أدناه. قناة الشفافية احتفظت بكل درجاتها ذات 8 بت.
- افحص الحدة بالحجم الفعلي، واعمل اختبار طباعة قبل استخدام المنتجات الكبيرة.

## الخلفية
- الركن الأبيض الذي قد يظهر في بعض برامج العرض يكون خلفية برنامج العرض، وليس جزءًا من الملف.
- افتح PNG في محرر يدعم الشفافية أو ضعه فوق خلفية ملونة للتأكد.

## تنبيه التصميم رقم 05
- ملف العربية يحتفظ بعلامة DRAFT: ما زال يحتاج إعادة تصميم قبل النشر بسبب التشابه المحتمل مع أشكال سيارات حقيقية.
- التكبير لا يغير حالة مراجعة الحقوق لأي تصميم.
- المجموعة ليست تصريحًا قانونيًا أو ضمانًا للمبيعات؛ راجع حقوق الاستخدام التجاري والتشابهات قبل النشر.

## Technical export facts
- All ten images: 7000 x 7000, 8-bit RGBA PNG, real alpha transparency.
- Source images: 1024 x 1024. Resizing: premultiplied-alpha Lanczos interpolation, not AI reconstruction.
- RGB optimization: 32 levels per RGB channel, with a maximum rounding difference of 4/255; see the manifest.
- These files remain full RGBA, not indexed-color PNG. All 256 alpha values are available.
- The RGB of completely invisible pixels is cleared to zero to prevent matte artifacts.
- Corners are fully transparent; central badge pixels remain fully opaque.
- No artwork was redrawn, and no source file was overwritten.
