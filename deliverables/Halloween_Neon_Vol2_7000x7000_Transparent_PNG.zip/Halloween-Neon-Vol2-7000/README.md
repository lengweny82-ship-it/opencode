# Halloween Neon - Vol.2 - 7000 x 7000 Transparent PNG

## الملفات
- المجموعة الثانية: 10 صور جديدة، كل صورة 7000×7000 بكسل فعلًا.
- الصيغة PNG ونظام الألوان RGBA، مع شفافية حقيقية خارج التصميم.
- الخلفية البنفسجي داخل الدائرة والشخصيات والإطار الكريمي جزء من الرسمة، وليست خلفية بيضاء محذوفة.
- ملفات manifest.csv وmanifest.json توضح المقاس والصيغة والشفافية وبصمة كل ملف.

## طريقة التكبير
- الصور الأصلية 1024×1024، وتم تكبيرها بخوارزمية Lanczos مع معالجة صحيحة لحواف الشفافية.
- ده تكبير حسابي، مش إعادة توليد ولا AI super-resolution، ومش بيخلق تفاصيل أصلية جديدة بدقة 7000.
- تمت إضافة بيانات 300 DPI، لكن تغيير DPI وحده لا يضيف تفاصيل.
- تم تحسين خطوات RGB لتقليل حجم التحميل، والفرق اللوني موضح أدناه. قناة الشفافية احتفظت بكل درجاتها ذات 8 بت.
- افحص الحدة بالحجم الفعلي، واعمل اختبار طباعة قبل المنتجات الكبيرة.

## الخلفية
- الركن الأبيض الذي قد يظهر في بعض برامج العرض يكون خلفية برنامج العرض، وليس جزءًا من الملف.
- افتح PNG في محرر يدعم الشفافية أو ضعه فوق خلفية ملونة للتأكد.

## Technical export facts
- All ten images: 7000 x 7000, 8-bit RGBA PNG, real alpha transparency.
- Source images: 1024 x 1024. Resizing: premultiplied-alpha Lanczos interpolation, not AI reconstruction.
- RGB optimization: 32 levels per RGB channel, maximum rounding difference 4/255; see the manifest.
- These files remain full RGBA, not indexed-color PNG. All 256 alpha values are available.
- The RGB of completely invisible pixels is cleared to zero to prevent matte artifacts.
- Corners are fully transparent; central badge pixels remain fully opaque.
- No artwork was redrawn, and no source file was overwritten.
- This is the second set (Vol.2). The first set is in Halloween_Neon_7000x7000_Transparent_PNG.zip.
- Not a legal clearance and not a guarantee of sales.
